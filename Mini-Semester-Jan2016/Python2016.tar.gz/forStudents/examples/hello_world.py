#!/usr/bin/python

# This is a single-line comment
print 'hello world!'
print 'hello again'

for i in range(100):
    print i
#    print i+1

""" This is 
a multiline
comment"""

''' This is also 
a multiline
comment'''

