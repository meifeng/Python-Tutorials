import random

N = 100
for i in range(N):
    print i, random.random()
